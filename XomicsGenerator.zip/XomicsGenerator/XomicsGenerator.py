try:
    import GEOparse
    import pandas as pd
    import mygene
    import numpy as np
    import os
    import sys
    import re
except ImportError as e:
    module_name = str(e).split(" ")[-1]  # Obtener el nombre de la librería que no se pudo importar
    print(f"Error: Library {module_name} is not installed.")
    install_module = input(f"¿Would you like to install {module_name}? (y/n): ")
    
    if install_module.lower() == 'y':
        try:
            # Instalar la librería utilizando pip
            import subprocess
            subprocess.check_call([sys.executable, "-m", "pip", "install", module_name])
            print(f"Library {module_name} has been installed.")
            
            # Importar la librería recién instalada
            globals()[module_name] = __import__(module_name)
            
        except Exception as install_error:
            print(f"Error: library {module_name} could not been installed: {install_error}")
            sys.exit(1)
    else:
        print("This programm can not been executed without this library, please install it and then execute the programm again.")
        sys.exit(1)


def main(filename):
    gse, filename = file_recognition(filename)
    matrix = file_processing(filename)
    samples = get_samples(gse)
    gene_symbols = get_gene_symbols(matrix)
    entrez_ids = gene_symbols_to_entrez(gene_symbols)
    expression_data = get_expression_data(matrix)
    generate_expression_matrix(samples,entrez_ids,expression_data)


def file_recognition(filename):
    """
    Retrieves a GEO dataset based on the provided filename.

    Args:
        filename (str): The filename containing the GEO accession ID.

    Returns:
        GEOparse object or None: The GEOparse object if the dataset is found,
        otherwise None.

    Raises:
        SystemExit: If the filename does not match the expected pattern or if
                    the dataset with the provided ID is not available in the GEO
                    database.
    """
    pattern = r'GSE\d{6}'
    match = re.match(pattern,filename)
    if match:
        accesion_id = match.group(0)
    else:
        print(f'Error: GEO accesion ID provided is not valid, please review.')
        sys.exit(1) 
    gse = GEOparse.get_GEO(geo=accesion_id, destdir="./",include_data=True,silent=True) # create a GEO object
    os.remove(f'{accesion_id}_family.soft.gz')   # remove the soft file
    if not gse:
        print(f'Error: The dataset with the provided ID: {accesion_id} is not currently available in the GEO (Gene Expression Omnibus) database.')
        sys.exit(1)
    print('..............................................')
    print(f'PROCESSING DATASET, ACCESSION ID: {accesion_id}')
    print('..............................................')
    return gse, filename


def file_processing(filename):
    """    
    Process a data file and return a nested list called "matrix".

    Args:
        filename (str): The name of the file to process.

    Returns:
        list: A list of lists representing the data matrix.

    Raises:
        ValueError: If the file extension is not .csv, .txt, or .tsv.
    """
    if filename.endswith('.csv'):
        delimiter = ','
    elif filename.endswith('.txt') or filename.endswith('.tsv'):
        delimiter = '\t'
    else:
        raise ValueError("File needs to have extension csv, txt or tsv")
    
    with open(filename, 'r') as f:
        file = f.read()

    if file.endswith('\n'): # remove the last element of file if it is an empty element
        file = file[:-1]

    lines = file.split('\n')
    matrix = [line.split(delimiter) for line in lines]  # generete nested list where each list is consider as a row of matrix
    
    return matrix


def get_samples(gse):
    """   
    Get the names of samples associated with an accession ID.

    Args:
        gse (GEOparse object): GEOparse object that cointains all information about the dataset.

    Returns:
        list: A list of sample names.

    Note:
        Uses the GEOparse library to retrieve the data.
    """
    samples = [gse.gsms[id].metadata['title'][0] for id in gse.gsms.keys()] # create a list of sample names        
    return samples


def get_gene_symbols(matrix):
    """    
    Get gene symbols from a data matrix.

    Args:
        matrix (list): The data matrix.

    Returns:
        list: A list of gene symbols.

    Note:
        Assumes that the symbols are in the first column of the matrix.
    """
    gene_symbols = [row[0] for row in matrix][1:]  # create a list of gene symbols
    return gene_symbols


def gene_symbols_to_entrez(gene_symbols):
    """    
    Map gene symbols to entrez IDs.

    Args:
        gene_symbols (list): A list of gene symbols.

    Returns:
        list: A list of corresponding entrez IDs. Returns None if not found.

    Note:
        Uses MyGeneInfo to perform the mapping.
    """
    mg = mygene.MyGeneInfo()
    entries = mg.querymany(gene_symbols,scopes='symbol',fields='entrezgene',species='human',returnall=True,entrezonly=True)  # make a query based on gene symbols list
    entrez_ids = []
    for i,entry in enumerate(entries['out']):
        if i < len(entries['out']) - 1 and entry['query'] == entries['out'][i + 1]['query']:
            if 'entrezgene' in entry:
                continue
        elif 'entrezgene' in entry:   
            entrez_ids.append(entry['entrezgene'])
        elif 'notfound' in entry and entry['notfound']: # if query return zero results, set None as the mapped entrez gene id
            entrez_ids.append(None)
        elif 'entrezgene' not in entry and 'notfound' not in entry and not any(entry['query'] == item[0] for item in entries['dup']):
            entrez_ids.append(None)
    return entrez_ids


def get_expression_data(matrix):
    """    
    Get expression data from a data matrix.

    Args:
        matrix (list): The data matrix.

    Returns:
        numpy.ndarray: A numpy array representing the expression data.

    Note:
        Assumes that the expression data is in columns 2 and onwards.
    """
    expression_data = [row[1:] for row in matrix[1:]]
    expression_data = np.array(expression_data) # create a numpy array
    return expression_data


def generate_expression_matrix(samples, entrez_ids, expression_data):
    """
    Generate expression matrices for each sample and save them as CSV files.

    Args:
        samples (list): List of sample names.
        entrez_ids (list): List of entrez IDs corresponding to genes.
        expression_data (numpy.ndarray): Numpy array of expression data.

    Returns:
        None

    Note:
        Saves CSV files in a folder named 'Expression matrix results'.
    """
    output_folder = 'results'
    os.makedirs(output_folder,exist_ok=True)    # verify if output folder was created before
    mapped_data = [(gene, expVal) for gene, expVal in zip(entrez_ids, expression_data[:,:]) if gene != None]    # mapped each entrez id to his expression values by sample, if gene symbols could not been mapped it will not be consider
    for i, sample in enumerate(samples):
        dic = {}
        dic['genes'] = [elem[0] for elem in mapped_data]
        dic['expVal'] = [elem[1][i] for elem in mapped_data]
        df = pd.DataFrame(dic)
        df = df[(df['expVal'] != str(0))]    # select only genes with expVal != 0
        df.to_csv(os.path.join(output_folder,f'{sample}_Xomics.txt'), index=False)  # create a csv file with expression gene matriz per sample
    print('..............................................')
    print(f'WORK DONE, FILES WERE CREATED AND SAVED IN "{output_folder}" FOLDER')
    print('..............................................')
    return None


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print('Error')
        print("Usage: XomicsGenerator.py <filename>")
        sys.exit(1)
    main(sys.argv[1])

